let cart = JSON.parse(localStorage.getItem('cart')) || [];

function addToCart(cakeName) {
    cart.push(cakeName);
    localStorage.setItem('cart', JSON.stringify(cart));
    alert(cakeName + " added to cart!");
}
